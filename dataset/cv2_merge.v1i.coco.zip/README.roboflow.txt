
cv2_merge - v1 2021-03-26 1:46am
==============================

This dataset was exported via roboflow.ai on March 26, 2021 at 5:49 AM GMT

It includes 791 images.
Cv2 are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -15 and +15 degrees
* Random shear of between -15° to +15° horizontally and -15° to +15° vertically


