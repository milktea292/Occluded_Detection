
occluded_cv2 - v1 cv2_semester_project_occluded
==============================

This dataset was exported via roboflow.ai on May 8, 2021 at 10:34 PM GMT

It includes 180 images.
Cv2 are annotated in COCO format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


